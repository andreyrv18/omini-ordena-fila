# omini-ordena-fila
Ordena a fila do Omini do mais antigo ao mais novo
